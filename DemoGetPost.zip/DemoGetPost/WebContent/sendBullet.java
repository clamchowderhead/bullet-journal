@WebServlet(urlPatterns = {"/sendBullet"})
public class sendBullet extends HttpSevlet
{
	public void doPost(HttpServletRequest req, HttpServletResponse res)
	{
		string output = "The post is working";

		PrintWriter out = res.getWRiter();
		out.println(output);
	}
}