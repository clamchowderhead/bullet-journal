bullet1= {'text': 'Do homework', 'type': '>', 'priority': '!', 'date': '2017-10-01'}; // Mock JSON response from server


    (document.getElementById('firstbull').innerHTML=(bullet1.priority + ' ' + bullet1.type + '  ' + bullet1.text + '<br/>'));