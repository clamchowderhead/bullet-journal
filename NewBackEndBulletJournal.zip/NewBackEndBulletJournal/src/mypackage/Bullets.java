package mypackage;

public class Bullets {
	public String bullet;
	public String date;



public void setBullet(String bullet) {
	this.bullet= bullet;
}

public String getBullet() {
	return bullet;
}

public void setDate(String date) {
	this.date= date;
}

public String getDate() {
	return date;
}

public String entry() {
	return "You entered: " + bullet + " for "+ date + ".";
}

}